#!/bin/zsh
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LABEL="com.neogenesis.cmux-pet-overlay"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
mkdir -p "$ROOT/.build"
mkdir -p "$HOME/Library/LaunchAgents"

"$ROOT/scripts/build.sh" >/dev/null
"$ROOT/scripts/stop.sh" >/dev/null 2>&1 || true

cat > "$PLIST" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>$LABEL</string>
  <key>ProgramArguments</key>
  <array>
    <string>$ROOT/.build/cmux-pet-overlay</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>StandardOutPath</key>
  <string>$ROOT/.build/cmux-pet-overlay.log</string>
  <key>StandardErrorPath</key>
  <string>$ROOT/.build/cmux-pet-overlay.log</string>
</dict>
</plist>
PLIST

launchctl bootstrap "gui/$(id -u)" "$PLIST"
launchctl kickstart -k "gui/$(id -u)/$LABEL" >/dev/null 2>&1 || true

sleep 1
PID="$(pgrep -f "$ROOT/.build/cmux-pet-overlay" | head -n 1 || true)"
if [[ -n "$PID" ]] && ps -p "$PID" >/dev/null 2>&1; then
  echo "$PID" > "$ROOT/.build/cmux-pet-overlay.pid"
  echo "cmux-pet-overlay started: $PID"
else
  echo "cmux-pet-overlay failed to stay running; see .build/cmux-pet-overlay.log" >&2
  exit 1
fi
