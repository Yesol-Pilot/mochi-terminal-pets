#!/bin/zsh
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LABEL="com.neogenesis.cmux-pet-overlay"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"

launchctl bootout "gui/$(id -u)" "$PLIST" >/dev/null 2>&1 || true
pkill -f "$ROOT/.build/cmux-pet-overlay" 2>/dev/null || true
rm -f "$ROOT/.build/cmux-pet-overlay.pid"
echo "cmux-pet-overlay stopped"
