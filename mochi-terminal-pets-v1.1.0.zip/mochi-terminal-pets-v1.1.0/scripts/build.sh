#!/bin/zsh
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/.build"

clang \
  -fobjc-arc \
  -ObjC \
  -Wall \
  -Wextra \
  -Wno-unused-parameter \
  -framework Cocoa \
  "$ROOT/src/main.m" \
  -o "$ROOT/.build/cmux-pet-overlay"

echo "$ROOT/.build/cmux-pet-overlay"
